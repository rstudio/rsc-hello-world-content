library(connectapi)
library(httr)
library(shiny)
library(DT)
library(dplyr)

ui <- fluidPage(
  titlePanel("Connect Deployments Report"),
  #sliderInput("slider", "Scale Table Font:", min = 5, max = 30, value = 12),
  checkboxInput("includeUsageData", "Include last access time (this is slow)", value = FALSE),
  DTOutput("contentTable")
)


server <- function(input, output, session) {
  #previousValue <- reactiveVal(isolate(input$includeUsageData))
  
  
  merged_data2 <- reactive({
    
    merged_data <- reactiveVal(NULL)
    
    withProgress(message = 'Pulling API Data', value = 0, {
      
      client <- connect(  server = 'http://localhost:3939',
                          api_key = 'ahF4EwonCpeHVLdByWjtCNmncGvWAc4o')
      
      # get all users
      users <- get_users(client, limit = Inf)
      content <- get_content(client)
      
      merged_data <- merge(content, users[, c("guid", "email", "first_name", "last_name")], 
                           by.x = "owner_guid", by.y = "guid", all.x = TRUE)
      merged_data <- merged_data %>% select("id", "owner_guid", "guid", "name", "email", "access_type", "first_name", "last_name", "title", "description", "last_deployed_time", "created_time", "app_mode", "r_version", "py_version", "quarto_version", "run_as", "run_as_current_user", "dashboard_url")
      
      
      #checkbox
      if(input$includeUsageData) {
        # Include usage data
        
        result_df <- data.frame(guid = character(), time = as.POSIXct(character()), stringsAsFactors = FALSE)
        totrows = nrow(content)
        setProgress(0)
        result_list <- lapply(1:totrows, function(i) {
          row = content[i,]
          tmpusage <- get_usage_static(client,
                                       content_guid=row$guid,
                                       limit=1,
                                       asc_order=FALSE)
          incProgress(i/totrows/10, detail = paste0("Gathering usage data for ", i, " of ", totrows))
          if (nrow(tmpusage) > 0) {
            return(data.frame(content_guid = row$guid, time = tmpusage$time, stringsAsFactors = FALSE))
          } else {
            return(NULL)
          }
        })
        
        # Remove NULLs and bind all data frames together
        result_df <- do.call(rbind, result_list)
        merged_data <- merge(merged_data, result_df[, c("content_guid", "time")], 
                             by.x = "guid", by.y = "content_guid", all.x = TRUE)          
        merged_data <- rename(merged_data, last_access = time)
        
        data.frame(merged_data)
      } else {
        data.frame(merged_data)
      }
    })      
    
  })
  
  output$contentTable <- renderDT({
    datatable(
      merged_data2(),
      options = list(pageLength = 25,
                     dom = 'Blfript', 
                     paging = TRUE,
                     searching = TRUE,
                     fixedColumns = TRUE,
                     autoWidth = TRUE,
                     ordering = TRUE,
                     dom = 'tB',
                     buttons = list(
                       'copy', 'csv', 'excel',
                       list(
                         extend = "colvis"
                       )
                     ),
                     lengthMenu = list(c(10, 25, 50, 100, -1), c('10', '25', '50', '100', 'All'))
      ),
      filter = "top",
      style = "bootstrap",
      class = "display",
      extensions = 'Buttons',
      callback = JS(paste0("
                                                  table.on('draw', function(){
                                                    $('table.dataTable').css('font-size', '", 
                           input$slider, 
                           "px');
                                                  });")
      )
      
      
    )
  })
  
  
}

shinyApp(ui, server)